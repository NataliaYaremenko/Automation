# encoding: utf-8
# module _wmi
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python312\DLLs\_wmi.pyd
# by generator 1.147
# no doc
# no imports

# functions

def exec_query(*args, **kwargs): # real signature unknown
    """
    Runs a WMI query against the local machine.
    
    This returns a single string with 'name=value' pairs in a flat array separated
    by null characters.
    """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x00000218620558E0>'

__spec__ = None # (!) real value is "ModuleSpec(name='_wmi', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x00000218620558E0>, origin='C:\\\\BuildAgent\\\\system\\\\.persistent_cache\\\\pycharm\\\\pythons4utils\\\\python312\\\\DLLs\\\\_wmi.pyd')"

