# encoding: utf-8
# module _uuid
# from C:\BuildAgent\system\.persistent_cache\pycharm\pythons4utils\python39\DLLs\_uuid.pyd
# by generator 1.147
# no doc
# no imports

# Variables with simple values

has_uuid_generate_time_safe = 0

# functions

def UuidCreate(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x000001EE17607850>'

__spec__ = None # (!) real value is "ModuleSpec(name='_uuid', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x000001EE17607850>, origin='C:\\\\BuildAgent\\\\system\\\\.persistent_cache\\\\pycharm\\\\pythons4utils\\\\python39\\\\DLLs\\\\_uuid.pyd')"

